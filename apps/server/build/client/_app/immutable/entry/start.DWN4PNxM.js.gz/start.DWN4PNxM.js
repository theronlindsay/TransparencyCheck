import{l as o,a as r}from"../chunks/CrpFs2Bk.js";export{o as load_css,r as start};
